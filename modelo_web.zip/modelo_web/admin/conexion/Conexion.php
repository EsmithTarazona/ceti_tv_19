<?php

class Conexion
{

    private $server = "localhost";
    private $usuario="root";
    private $clave="";
    private $db="mi_tienda";
    private $mysqlis;

    public $campos;
    public $tabla;
    public $condicion;

    function CadenaConexion()
    {
        $this->mysqlis = mysqli_connect($this->server,$this->usuario,$this->clave,$this->db);

        if($this->mysqlis->connect_errno)
        {
            echo "Fallo al conectar con la Base de Datos : ".$this->mysqlis->connect_errno;
        }

        return $this->mysqlis;
    }

    function ConsultasCondicion()
    {
        $this->CadenaConexion();
        $sql ="SELECT ".$this->campos." FROM ".$this->tabla." WHERE ".$this->condicion;
        $rs = mysqli_query($this->mysqlis,$sql);
        return $rs;
    }

    function Consultas()
    {
        $this->CadenaConexion();
        $sql ="SELECT ".$this->campos." FROM ".$this->tabla;
        $rs = mysqli_query($this->mysqlis,$sql);
        return $rs;
    }

}

?>