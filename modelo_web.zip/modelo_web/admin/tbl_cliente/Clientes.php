<?php
    class clientes
    {

        Public $id;
        Public $nombre_completo;
        Public $telefono;
        Public $correo;
        Public $dni ;
        Public $direccion ;
    

        function Agregar($cn){
            $sql = "INSERT INTO clientes (nombre_completo,telefono,correo) values ('".$this->nombre_completo."','".$this->telefono."','".$this->correo."');";
            $rs = mysqli_query($cn,$sql);
            return $rs;
        }

        function Actualizar($cn){
           ECHO $sql = "UPDATE clientes SET dni = '".$this->nombre."',
                                             direccion = '".$this->apellido."'
                                            WHERE  id = ".$this->id;

            $rs = mysqli_query($cn,$sql);
            return $rs;
        }

    }
?>