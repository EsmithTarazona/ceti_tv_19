<?php
    include('../conexion/Conexion.php');
    include('Clientes.php');

    $cn = new Conexion();
    $clie = new clientes();

    $clie->nombre_completo = $_POST['nombre'];
    $clie->telefono = $_POST['telefono'];
    $clie->correo = $_POST['mail'];

    
    if( $clie->nombre_completo == "" or
    $clie->telefono == "" or
    $clie->correo == ""  )
    {
            echo "Complete los datos";
    }
    else
    {
        $clie->Agregar($cn->CadenaConexion());
        session_start();
        $_SESSION['nombre'] = $clie->nombre_completo;

        echo "Cliente Registrado";
    }
?>