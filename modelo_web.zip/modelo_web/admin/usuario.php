<?php include('head.php');  ?>

    <!-- Page Wrapper -->
    <div id="wrapper">
        <?php include('menu.php');?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <?php include('header.php')?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Registro de Usuarios</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">FORMULARIO USUARIO</h6>
                                    </div>
                                    <div class="card-body" id="frm_usuario">
                                        <form>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Nombre </label>
                                                <input type="text" class="form-control" id="txt_nombre" aria-describedby="Ingrese nombre">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputPassword1" class="form-label">Apellido</label>
                                                <input type="text" class="form-control" id="txt_apellido">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputPassword1" class="form-label">Usuario</label>
                                                <input type="text" class="form-control" id="txt_usuario">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputPassword1" class="form-label">Contraseña</label>
                                                <input type="password" class="form-control" id="txt_clave">
                                            </div>
                                            <div class="mb-3">
                                                <label for="exampleInputPassword1" class="form-label">Estado</label>
                                                    <select class="form-control" id="txt_estado" aria-label="Default select example">
                                                        <option value="">-SELECCIONAR-</option>
                                                        <option selected value="1">Activo</option>

                                                     </select>
                                            </div>
                                            <button type="button" onclick='Agregar()' class="btn btn-success">
                                                <span class = "fa fa-save"></span>
                                                Guardar
                                            </button>
                                            <div id="rpt"></div>
                                        </form>
                                    </div>
                                </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">LISTADO DE USUARIO</h6>
                                    </div>
                                    <div class="card-body" id="lista">

                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->
            <?php include('footer.php');?>
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->
<?php include('foot.php'); ?>
<script src="tbl_usuario/usuario.js"></script>
<script>
    $(document).ready(function(){
        listar();
    });
</script>