<?php
    include('../conexion/Conexion.php');

    $cn = new Conexion();

    $usuario = $_POST['user'];
    $clave = $_POST['pass'];


    $cn->campos = "*";
    $cn->tabla = "v_usuario_rol";
    $cn->condicion = " nick = '".$usuario."' and clave = '".sha1($clave)."' ";
    $rs = $cn->ConsultasCondicion();

    $numregis = mysqli_num_rows($rs);

    if($numregis>0)
    {
        $datos = mysqli_fetch_object($rs);

        session_start();

        $_SESSION['nombre'] = $datos->nombre;
        $_SESSION['apellido'] = $datos->apellidos;
        $_SESSION['usuario'] = $datos->nick;
        $_SESSION['estado'] = $datos->estado_usuario;
        $_SESSION['rol'] = $datos->nombre_rol;

        if($_SESSION['estado']=="ACTIVADO")
        {
            echo 1;
        }
        else
        {
           echo 2;
        }
        
    }
    else
    {
        echo 3;
    }

?>