<?php
    class Usuario
    {
        Public $id;
        Public $nombre;
        Public $apellido;
        Public $usuario;
        Public $clave;
        Public $estado;
    

        function Agregar($cn){
            $sql = "INSERT INTO usuarios (nombre,apellidos,nick,contraseña,estado) values ('".$this->nombre."','".$this->apellido."','".$this->usuario."','".sha1('$this->clave')."',".$this->estado.");";
            $rs = mysqli_query($cn,$sql);
            return $rs;
        }

        function Actualizar($cn){
           ECHO $sql = "UPDATE usuarios SET nombre = '".$this->nombre."',
                                        apellidos = '".$this->apellido."',
                                        nick = '".$this->usuario."',
                                        contraseña = '".sha1('$this->clave')."',
                                        estado =    ".$this->estado." 
                    WHERE  id = ".$this->id;

            $rs = mysqli_query($cn,$sql);
            return $rs;
        }

    }
?>