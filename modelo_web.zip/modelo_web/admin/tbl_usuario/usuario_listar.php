<?php
    include ('../conexion/Conexion.php');

    $cn = new Conexion();
    $cn->campos = "*";
    $cn->tabla = "usuarios";
    $rs = $cn->Consultas();
?>
<div class="table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead class="bg bg-primary text-white">
            <tr>
                <th>NOMBRE</th>
                <th>APELLIDO</th>
                <th>USUARIO</th>
                <th>CONTRASEÑA</th>
                <th>ESTADO</th>
                <th>EDITAR</th>
            </tr>
        </thead>
        <tfoot class="bg bg-primary text-white">
            <tr>
                <th>NOMBRE</th>
                <th>APELLIDO</th>
                <th>USUARIO</th>
                <th>CONTRASEÑA</th>
                <th>ESTADO</th>
                <th>EDITAR</th>
            </tr>
        </tfoot>
        <tbody>
            <?php
                while($columna = mysqli_fetch_object($rs)){
            ?>
            <tr>
                <td><?=$columna->nombre?></td>
                <td><?=$columna->apellidos?></td>
                <td><?=$columna->nick?></td>
                <td>******</td>
                <td>
                    <?PHP
                        if($columna->estado==1)
                        {
                            echo "ACTIVO";
                        }
                        else
                        {
                            echo "DE BAJA";
                        }
                    ?>
                </td>
                <th>
                    <Button class="btn btn-warning" onclick="editar(<?=$columna->id?>)"><span class="fa fa-pen"><span></buttom>
                </th>
            </tr>
            <?php
                }
            ?>
        </tbody>
    </table>
</div>
<script>
    $(document).ready(function() {
          $('#dataTable').DataTable();
    });
</script>
