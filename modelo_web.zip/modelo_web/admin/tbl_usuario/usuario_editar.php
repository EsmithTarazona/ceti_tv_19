<?php
include ('../conexion/Conexion.php');
$cn = new Conexion();

$id = $_POST['id'];
$cn->campos = "*";
$cn->tabla = " usuarios ";
$cn->condicion = " id = ".$id;
$rs = $cn->ConsultasCondicion();
$datos = mysqli_fetch_object($rs);

?>
<form>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Nombre </label>
        <input type="text" class="form-control" id="txt_nombre" aria-describedby="Ingrese nombre" value="<?=$datos->nombre?>">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Apellido</label>
        <input type="text" class="form-control" id="txt_apellido"  value="<?=$datos->apellidos?>">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Usuario</label>
        <input type="text" class="form-control" id="txt_usuario"  value="<?=$datos->nick?>">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Contraseña</label>
        <input type="password" class="form-control" id="txt_clave"  value="<?=$datos->contraseña?>">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Estado</label>
            <select class="form-control" id="txt_estado" aria-label="Default select example">
                <option value="">-SELECCIONAR-</option>
                <option <?=$datos->estado==0?"selected":""?> value="0">DE BAJA</option>
                <option <?=$datos->estado==1?"selected":""?> value="1">ACTIVO</option>
                </select>
    </div>
    <button type="button" onclick='Actualizar(<?=$id?>)' class="btn btn-success">
        <span class = "fa fa-save"></span>
        Actualizar
    </button>
    <a href="usuario.php" type="button" class="btn btn-danger">
        <span class = "fa fa-times"></span>
        Cancelar
    </a>
    <div id="rpt"></div>
</form>