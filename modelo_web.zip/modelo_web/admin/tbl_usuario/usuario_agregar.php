<?php
    include('../conexion/Conexion.php');
    include('Usuario.php');

    $cn = new Conexion();
    $user = new Usuario();

    $user->nombre = $_POST['nombre'];
    $user->apellido = $_POST['apellido'];
    $user->usuario = $_POST['usuario'];
    $user->clave = $_POST['clave'];
    $user->estado = $_POST['estado'];


    $user->Agregar($cn->CadenaConexion());

    echo "Usuario Agregado";
?>