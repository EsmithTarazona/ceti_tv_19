function Agregar()
{
    nombre = $("#txt_nombre").val();
    apellido = $("#txt_apellido").val();
    usuario = $("#txt_usuario").val();
    clave = $("#txt_clave").val();
    estado = $("#txt_estado").val();

    var parametros = {
        "nombre" : nombre,
        "apellido" : apellido,
        "usuario" : usuario,
        "clave" : clave,
        "estado" : estado
    }

    $.ajax({
        data: parametros,
        url : "tbl_usuario/usuario_agregar.php",
        type : 'post',
        beforeSend: function(){
            $("#rpt").html ("Enviando Datos...");
        },
        success: function (response)
        {
            $("#rpt").html (response);
            listar()
        }
    }
    );
}


function listar()
{
    $.ajax({
        url : "tbl_usuario/usuario_listar.php",
        type : 'post',
        beforeSend: function(){
            $("#lista").html ("Cargando Datos...");
        },
        success: function (response)
        {
            $("#lista").html(response);
        }
    }
    );

}

function editar(id)
{
    var parametros = {
        "id" : id
    }

    $.ajax({
        data: parametros,
        url : "tbl_usuario/usuario_editar.php",
        type : 'post',
        beforeSend: function(){
            $("#frm_usuario").html ("Enviando Datos...");
        },
        success: function (response)
        {
            $("#frm_usuario").html (response);
        }
    }
    );
}

function Actualizar(id)
{

    nombre = $("#txt_nombre").val();
    apellido = $("#txt_apellido").val();
    usuario = $("#txt_usuario").val();
    clave = $("#txt_clave").val();
    estado = $("#txt_estado").val();

    var parametros = {
        "nombre" : nombre,
        "apellido" : apellido,
        "usuario" : usuario,
        "clave" : clave,
        "estado" : estado,
        "id" : id
    }

    $.ajax({
        data: parametros,
        url : "tbl_usuario/usuario_actualizar.php",
        type : 'post',
        beforeSend: function(){
            $("#rpt").html ("Enviando Datos...");
        },
        success: function (response)
        {
            $("#rpt").html (response);
            listar()
        }
    }
    );

}