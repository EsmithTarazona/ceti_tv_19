function logear()
{
    usuario = $("#txt_user").val();
    clave = $("#pasw_password").val();

    var parametros = {
        "user" : usuario,
        "pass" : clave
    }


    $.ajax({
        data: parametros,
        url : "controler/interlogin.php",
        type : 'post',
        beforeSend: function(){
            $("#rpt").html ("Validando Datos...");
        },
        success: function (response)
        {
            if(response==1)
            {
                window.open('index.php',"_self");
            }
            else
            {
                if(response==2)
                {
                    $("#rpt").html("Usuario Desactivado");
                }
                else
                {
                    if(response==3)
                    {
                        $("#rpt").html("Datos Incorrectos");
                    }  
                }

            }
            
        }
    }
    );

}