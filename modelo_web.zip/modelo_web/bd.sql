-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         10.4.28-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para mi_tienda
DROP DATABASE IF EXISTS `mi_tienda`;
CREATE DATABASE IF NOT EXISTS `mi_tienda` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `mi_tienda`;

-- Volcando estructura para tabla mi_tienda.almacen
DROP TABLE IF EXISTS `almacen`;
CREATE TABLE IF NOT EXISTS `almacen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `stock_actual` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_pro` (`id_producto`),
  CONSTRAINT `fk_id_pro` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.almacen: ~0 rows (aproximadamente)
DELETE FROM `almacen`;

-- Volcando estructura para tabla mi_tienda.carrito_detalles
DROP TABLE IF EXISTS `carrito_detalles`;
CREATE TABLE IF NOT EXISTS `carrito_detalles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_carrito` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `precio_unitario` decimal(5,2) NOT NULL,
  `Cantidad` int(11) DEFAULT NULL,
  `precio_total` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_carr` (`id_carrito`),
  KEY `fk_id_prod` (`id_producto`),
  CONSTRAINT `fk_id_carr` FOREIGN KEY (`id_carrito`) REFERENCES `carrito_principal` (`id`),
  CONSTRAINT `fk_id_prod` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.carrito_detalles: ~0 rows (aproximadamente)
DELETE FROM `carrito_detalles`;

-- Volcando estructura para tabla mi_tienda.carrito_principal
DROP TABLE IF EXISTS `carrito_principal`;
CREATE TABLE IF NOT EXISTS `carrito_principal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres_apellidos_comprador` varchar(70) NOT NULL,
  `numero_documento` varchar(12) NOT NULL,
  `Telefono` varchar(12) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `tipo_despacho` varchar(30) NOT NULL,
  `monto_subtotal` decimal(8,2) NOT NULL,
  `igv` decimal(8,2) NOT NULL,
  `monto_total` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.carrito_principal: ~0 rows (aproximadamente)
DELETE FROM `carrito_principal`;

-- Volcando estructura para tabla mi_tienda.categorias
DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.categorias: ~3 rows (aproximadamente)
DELETE FROM `categorias`;
INSERT INTO `categorias` (`id`, `nombre`) VALUES
	(1, 'ENTRADAS'),
	(2, 'PLATOS DE FONDO'),
	(3, 'PLATOS ESENCIALES');

-- Volcando estructura para tabla mi_tienda.clientes
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) DEFAULT NULL,
  `telefono` varchar(10) DEFAULT NULL,
  `correo` varchar(20) DEFAULT NULL,
  `dni` varchar(12) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.clientes: ~1 rows (aproximadamente)
DELETE FROM `clientes`;
INSERT INTO `clientes` (`id`, `nombre_completo`, `telefono`, `correo`, `dni`, `direccion`) VALUES
	(1, 'elias tarazona', '987656789', 'eliasmasna@gmail.com', NULL, NULL);

-- Volcando estructura para tabla mi_tienda.productos
DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `marca` varchar(30) NOT NULL,
  `precio_unitario` decimal(8,2) NOT NULL,
  `estado` int(11) NOT NULL,
  `imagen` varchar(200) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `codigo` varchar(5) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_cat` (`id_categoria`),
  CONSTRAINT `fk_id_cat` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.productos: ~3 rows (aproximadamente)
DELETE FROM `productos`;
INSERT INTO `productos` (`id`, `Nombre`, `id_categoria`, `marca`, `precio_unitario`, `estado`, `imagen`, `descripcion`, `codigo`, `stock`) VALUES
	(1, 'ENSALADA RUSA', 1, 'PERUANA', 15.60, 1, 'img/productos/Entrada/causa_cangrejo.jpg', 'Las entradas se pueden catalogar en calientes o frías, baratas o costosas, con carne o vegetarianas, entre otros tipos. Las posibilidades son infinitas. Ahora veremos una breve clasificación de entrad', 'ENT01', 3),
	(2, 'ENSALADA ', 1, 'PERUANA', 10.60, 1, 'img/productos/Entrada/causa_pollo.jpg', 'Las entradas se pueden catalogar en calientes o frías, baratas o costosas, con carne o vegetarianas, entre otros tipos. Las posibilidades son infinitas. Ahora veremos una breve clasificación de entrad', 'ENT02', 13),
	(3, 'TOMATES RELLENOS', 1, 'PERUANA', 28.90, 1, 'img/productos/Entrada/tomates-rellenos.jpg', 'Las entradas se pueden catalogar en calientes o frías, baratas o costosas, con carne o vegetarianas, entre otros tipos. Las posibilidades son infinitas. Ahora veremos una breve clasificación de entrad', 'ENT03', 2);

-- Volcando estructura para tabla mi_tienda.roles
DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.roles: ~2 rows (aproximadamente)
DELETE FROM `roles`;
INSERT INTO `roles` (`id`, `nombre`) VALUES
	(1, 'Administrativo'),
	(2, 'Ventas');

-- Volcando estructura para tabla mi_tienda.usuarios
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `apellidos` varchar(60) NOT NULL,
  `nick` varchar(30) NOT NULL,
  `contraseña` varchar(50) NOT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.usuarios: ~5 rows (aproximadamente)
DELETE FROM `usuarios`;
INSERT INTO `usuarios` (`id`, `nombre`, `apellidos`, `nick`, `contraseña`, `estado`) VALUES
	(1, 'JOSEFINA', 'TUMBEZ TAIPE', 'JTUMBES', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 1),
	(2, 'CARLOS', 'MONZON CAVASAS', 'CMONZON', '339aaa2e894927e1db26c2290c50efa2972a1f3e', 1),
	(3, 'LUIS ALBERTO', 'CASOS LARA', 'LCASOS', '339aaa2e894927e1db26c2290c50efa2972a1f3e', 1),
	(4, 'Maria', 'Gonzales Prada', 'MGONZALES', '339aaa2e894927e1db26c2290c50efa2972a1f3e', 1),
	(5, 'THALIA', 'CESPEDES MARTINEZ', 'THCESPE', '339aaa2e894927e1db26c2290c50efa2972a1f3e', 1);

-- Volcando estructura para tabla mi_tienda.usuarios_roles
DROP TABLE IF EXISTS `usuarios_roles`;
CREATE TABLE IF NOT EXISTS `usuarios_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_usu` (`id_usuario`),
  KEY `fk_id_rol` (`id_rol`),
  CONSTRAINT `fk_id_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_id_usu` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.usuarios_roles: ~2 rows (aproximadamente)
DELETE FROM `usuarios_roles`;
INSERT INTO `usuarios_roles` (`id`, `id_usuario`, `id_rol`) VALUES
	(1, 1, 2),
	(2, 2, 1);

-- Volcando estructura para tabla mi_tienda.ventas_principal
DROP TABLE IF EXISTS `ventas_principal`;
CREATE TABLE IF NOT EXISTS `ventas_principal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_carrito_principal` int(11) NOT NULL,
  `tipo_documento` varchar(30) DEFAULT NULL,
  `nro_documento` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_car_pri` (`id_carrito_principal`),
  CONSTRAINT `fk_id_car_pri` FOREIGN KEY (`id_carrito_principal`) REFERENCES `carrito_principal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.ventas_principal: ~0 rows (aproximadamente)
DELETE FROM `ventas_principal`;

-- Volcando estructura para tabla mi_tienda.venta_detalles
DROP TABLE IF EXISTS `venta_detalles`;
CREATE TABLE IF NOT EXISTS `venta_detalles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta_principal` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_ven_prin` (`id_venta_principal`),
  CONSTRAINT `fk_id_ven_prin` FOREIGN KEY (`id_venta_principal`) REFERENCES `ventas_principal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla mi_tienda.venta_detalles: ~0 rows (aproximadamente)
DELETE FROM `venta_detalles`;

-- Volcando estructura para vista mi_tienda.v_usuario_rol
DROP VIEW IF EXISTS `v_usuario_rol`;
-- Creando tabla temporal para superar errores de dependencia de VIEW
CREATE TABLE `v_usuario_rol` (
	`id` INT(11) NOT NULL,
	`nombre` VARCHAR(30) NOT NULL COLLATE 'utf8mb4_general_ci',
	`apellidos` VARCHAR(60) NOT NULL COLLATE 'utf8mb4_general_ci',
	`nick` VARCHAR(30) NOT NULL COLLATE 'utf8mb4_general_ci',
	`clave` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`estado_usuario` VARCHAR(11) NULL COLLATE 'utf8mb4_general_ci',
	`nombre_rol` VARCHAR(30) NOT NULL COLLATE 'utf8mb4_general_ci'
) ENGINE=MyISAM;

-- Volcando estructura para vista mi_tienda.v_usuario_rol
DROP VIEW IF EXISTS `v_usuario_rol`;
-- Eliminando tabla temporal y crear estructura final de VIEW
DROP TABLE IF EXISTS `v_usuario_rol`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_usuario_rol` AS SELECT 
	t1.id,
	t2.nombre,
	t2.apellidos,
	t2.nick,
	t2.`contraseña` AS clave,
	case t2.estado 
		when 1 then 'ACTIVADO'
		When 0 then 'DESACTIVADO'
	END AS estado_usuario, 	
	t3.nombre AS nombre_rol
FROM 
	usuarios_roles t1
	INNER JOIN usuarios t2 ON t1.id_usuario = t2.id
	INNER JOIN roles t3 ON t1.id_rol = t3.id ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
