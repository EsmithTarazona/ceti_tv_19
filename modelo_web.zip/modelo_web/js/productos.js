function listarTopProducto()
{
    $.ajax({
        url : "controler/top_producto.php",
        type : 'post',
        beforeSend: function(){
            $("#top_productos").html ("Cargando Datos...");
        },
        success: function (response)
        {
            $("#top_productos").html(response);
        }
    }
    );

}


function registraUsuario()
{

    nombre = $("#txt_nombre").val();
    telefono = $("#txt_telefono").val();
    mail = $("#txt_mail").val();


    var parametros = {
        "nombre" : nombre,
        "telefono" : telefono,
        "mail" : mail
    }

    $.ajax({
        data: parametros,
        url : "admin/tbl_cliente/cliente_agregar.php",
        type : 'post',
        beforeSend: function(){
            $("#rpt").html ("Enviando Datos...");
        },
        success: function (response)
        {
            $("#rpt").html (response);
            listar()
        }
    }
    );
}