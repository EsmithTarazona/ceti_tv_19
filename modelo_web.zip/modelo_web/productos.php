<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Restaurante Tarazona</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    </head>
    <?php
      include ('admin/conexion/Conexion.php');

      $cn = new Conexion();
      $cn->campos = "*";
      $cn->tabla = "productos";
      $cn->condicion = " id = ".$_GET['codigo'];
      $rs = $cn->ConsultasCondicion();
      $columna = mysqli_fetch_object($rs)
    ?>
    <body>
        <!-- Navigation-->
        <nav id="lbl_cabesera" class="navbar navbar-expand-lg navbar-light bg-light">

        </nav>

        <!-- Section-->
        <section class="py-5">
          <div id="productos_detalle" class="container px-4 px-lg-5 mt-5">
                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="admin/<?=$columna->imagen?>" class="img-fluid rounded-start" alt="...">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title"><?=$columna->Nombre?> - <?=$columna->codigo?></h5>
                        <p class="card-text"><?=$columna->descripcion?></p>
                        <span><small class="text-muted">Precio : </small></span><span><h3>S/.<?=$columna->precio_unitario?></h3></span>
                        <span><small class="text-muted">Platos Disponibles : </small></span><span><h6><?=$columna->stock?> unidades</h6></span>
                        <p class="card-text"><small class="text-muted">Ingrese Cantidad : </small></p>
                        <div class="col-md-2">
                          <input type="number" class="form-control"></input>
                        </div>
                        <br>
                        <div>
                            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal"><span class="bi bi-basket"></span> Agregar</button>
                        </div>
                      </div>
                    </div>
                  </div>
               </div>
          </div>
          <h5  class="container px-4 px-lg-5 mt-5">PRODUCTOS SIMILARES</h5>
          <?php
              $cn = new Conexion();
              $cn->campos = "*";
              $cn->tabla = "productos";
              $cn->condicion = " id <> ".$_GET['codigo'];
              $rs_detalle = $cn->ConsultasCondicion();
          ?>
          <div id="producto_similar" class="container px-4 px-lg-5 mt-5">
            <div class="row row-cols-1 row-cols-md-3 g-4">
              <?php
      
              while($columna_prod_simi = mysqli_fetch_object($rs_detalle))
              {
      
              ?>
              <div class="col">
                <div class="card">
                  <img src="admin/<?=$columna_prod_simi->imagen?>" class="card-img-top" height=220>
                  <div class="card-body">
                    <h5 class="card-title"><?=$columna_prod_simi->Nombre?></h5>
                    <p class="card-text"><?=$columna_prod_simi->descripcion?></p>
                    <br>
                    <a href="productos.php?codigo=<?=$columna_prod_simi->id?>" type="button" class="btn btn-warning" ><span class="bi bi-eye"></span> Ver mas</a>
                  </div>
                </div>
              </div>
              <?php
                }
              ?>
            </div>
          </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Registro</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <label for="basic-url" class="form-label">Ingrese nombre Completo</label>  
                <div class="input-group input-group-sm mb-3">
                  <span class="input-group-text" id="inputGroup-sizing-sm">
                    <span class="bi bi-person-badge"></span>
                  </span>
                  <input type="text" id="txt_nombre" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                <label for="basic-url" class="form-label">Ingrese Telefono</label>  
                <div class="input-group input-group-sm mb-3">
                  <span class="input-group-text" id="inputGroup-sizing-sm"><span class="bi bi-telephone"></span></span>
                  <input type="text" class="form-control" id="txt_telefono" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
                </div>
                  <label for="basic-url" class="form-label">Ingrese un correo</label>
                  <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">@</span>
                    <input type="text" id="txt_mail" class="form-control" placeholder="Ingrese Mail" aria-label="Correo Electronico" aria-describedby="basic-addon1">
                  </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" onclick="registraUsuario()">Guardar</button>
              </div>
              <div>
                  <center><span id="rpt"></span></center>
               </div>
            </div>
          </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="admin/vendor/jquery/jquery.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/productos.js"></script>
        <script>
            $(document).ready(function(){
                cabesera();
            });
        </script>
    </body>
</html>
